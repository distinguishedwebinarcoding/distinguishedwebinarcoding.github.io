//
//  Size+extensions.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import UIKit
import SPCCore

public extension Size {
    
    func scaleToFit(within availableSize: Size) -> Double {
        let aspectWidth = availableSize.width / width
        let aspectHeight = availableSize.height / height
        return min(aspectWidth, aspectHeight)
    }
    
    func scaledToFit(within availableSize: Size) -> Size {
        let aspectRatio = scaleToFit(within: availableSize)
        return Size(width: width * aspectRatio, height: height * aspectRatio)
    }

}
