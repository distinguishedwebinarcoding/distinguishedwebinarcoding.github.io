import Foundation

// ***************************
// MACRO Compomente Fotocamera
// ***************************


public class FotoCamera: Space  {
    
    // Crea i componenti
    let camera = CameraView()
    let pulsanteScatto = Button()
    let pulsanteInvertiCamera = Button()
    let cursoneZoom = Slider()
    let pulsanteAvviaFotocamera = Button()
    let pulsanteSpegniFotocamera = Button()
    let album = PhotoAlbumView()
    public var fotoScattata = Output<Image>()
    
    public override init() {
        super.init()
        backgroundImage = #imageLiteral(resourceName: "cloudBackground.png")
        borderColor = #colorLiteral(red: 0.31960779428482056, green: 0.5745099186897278, blue: 0.37647050619125366, alpha: 1.0)
        borderWidth = 3
        alpha = 1
        cornerRadius = 30
        camera.overlayImage = #imageLiteral(resourceName: "cf_floatyCloudsWP.png")
    
        let ilMioAlbum = PhotoAlbum(named: "Galleria foto")
                
        // Applica uno stile ai componenti
        camera.borderColor = #colorLiteral(red: -0.19941067695617676, green: 0.6003136038780212, blue: 0.6733719706535339, alpha: 1.0)
        camera.borderWidth = 3
        camera.cornerRadius = 15
        camera.isUsingFrontCamera = true
        pulsanteScatto.image = #imageLiteral(resourceName: "oceanShutterButton.png")
        pulsanteScatto.scale = 0.8
    
        pulsanteInvertiCamera.image = #imageLiteral(resourceName: "oceanArrowButton.png")
        pulsanteInvertiCamera.scale = 0.8
        cursoneZoom.sliderImage = #imageLiteral(resourceName: "pinkSunglasses.png")
        cursoneZoom.minimumTrackColor = #colorLiteral(red: 0.9372549653053284, green: 0.7921569347381592, blue: 1.0000005960464478, alpha: 1.0)
        cursoneZoom.maximumTrackColor = #colorLiteral(red: 0.5254901051521301, green: 0.30980387330055237, blue: 0.9960787892341614, alpha: 1.0)
        
        pulsanteScatto.pressed.connect(to: camera.trigger)
        pulsanteInvertiCamera.pressed.connect(to: invertiCamera)
        cursoneZoom.valueChanged.connect(to: zoom)
        
        album.album = ilMioAlbum
        album.borderWidth = 3
        album.borderColor = #colorLiteral(red: 0.9568631052970886, green: 0.643137514591217, blue: 0.7529411911964417, alpha: 1.0)
        album.captionStyle = TextStyle(.ChalkboardSE, fontSize: 18, color: #colorLiteral(red: 0.9019607901573181, green: 0.2313726842403412, blue: 0.4784313440322876, alpha: 1.0), alignment: .center)
        
        pulsanteSpegniFotocamera.image = #imageLiteral(resourceName: "Foto 6.png")
        pulsanteSpegniFotocamera.scale = 1.1
        pulsanteAvviaFotocamera.image = #imageLiteral(resourceName: "Foto 4.png")
        pulsanteAvviaFotocamera.scale = 1
        
        // Aggiungi i componenti allo spazio della fotocamera
        add(camera, at: Point(x: 0, y: 0), size: Size(width: 250, height: 250))
        add(pulsanteScatto, at: Point(x: 120, y: -155), size: Size(width: 50, height: 50))
        add(pulsanteInvertiCamera, at: Point(x: -120, y: -155), size: Size(width: 50, height: 50))
        add(cursoneZoom, at: Point(x: 0, y: -155), size: Size(width: 180, height: 50))
        add(album, at: Point(x: 0, y: -255))
        add(pulsanteSpegniFotocamera, at: Point(x: -180, y: 0))
        add(pulsanteAvviaFotocamera, at: Point(x: 180, y: 0))
        
        // Connetti la fotocamera alla vista album
        camera.photoTaken.connect(to: scatto)
        pulsanteSpegniFotocamera.pressed.connect(to: spegniFotocamera)
        pulsanteAvviaFotocamera.pressed.connect(to: avviaFotocamera)
        }

    func impostaPulsante(button: Button, emoji: String) {
                button.title = emoji
                button.backgroundColor = .clear
                button.scale = 2.0
            }
    
    public func attivaFotocamera() {
        camera.start()
        }
    
    
    func scatto(immagine: Image) {
        fotoScattata.notifyInputs(immagine)
    }
    
    // Fuzione slider per lo zoom della fotocamera posteriore
    func zoom(valore: Double){
        camera.zoom = valore + 0.5
    }
    
    func invertiCamera(tap: Pulse) {
        camera.isUsingFrontCamera = !camera.isUsingFrontCamera
    }
     
    func spegniFotocamera(tap: Pulse) {
        camera.overlayImage = #imageLiteral(resourceName: "cf_floatyCloudsWP.png")
        camera.stop()
    }
    
    func avviaFotocamera(tap: Pulse) {
        camera.reset()
        camera.start()
        }
}

