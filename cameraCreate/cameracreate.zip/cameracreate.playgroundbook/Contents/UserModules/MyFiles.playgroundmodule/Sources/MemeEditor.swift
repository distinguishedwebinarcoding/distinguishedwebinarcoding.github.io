import Foundation
import SPCComponents

// **********************************************************************
// Personalizza la funzione generaMeme() per creare il tuo Meme preferito
// **********************************************************************


public func generaMeme(spazio: Space){
    
    // Richiama la funzione addLabel() per posizionare una o più etichette testo personalizzate 
    
    addLabel("KEEP", fontSize: 30, color: #colorLiteral(red: 1.0429102182388306, green: 0.7579643130302429, blue: -0.27876120805740356, alpha: 1.0), to: spazio, at: Point(x: 0, y: 80))
  
    addLabel("CALM", fontSize: 30, color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0), to: spazio, at: Point(x: 0, y: 40))
    
    addLabel("AND", fontSize: 20, color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0), to: spazio, at: Point(x: 0, y: 0))
    
    addLabel("{ CODE }", fontSize: 30, color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0), to: spazio, at: Point(x: 0, y: -45))
    
    addLabel("ON", fontSize: 30, color: #colorLiteral(red: 0.9529411792755127, green: 0.686274528503418, blue: 0.13333334028720856, alpha: 1.0), to: spazio, at: Point(x: 0, y: -85))
}

