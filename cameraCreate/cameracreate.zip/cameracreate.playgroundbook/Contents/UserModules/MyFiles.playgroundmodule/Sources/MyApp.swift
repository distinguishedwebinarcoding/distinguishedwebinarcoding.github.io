import SPCComponents
import Foundation

// **********************************************************************
// Personalizza la funzione generaMeme() per creare il tuo Meme preferito
// **********************************************************************
 

public class MyApp: App {
    
    // Attiva i MACRO Compomenti necessari al funzionamento dell'app
    public let space = Space()
    let camera = FotoCamera()
    let editor = FotoEditor()
    
  public init() {
    // Aggiungi i componenti allo spazio
    space.add(camera, at: Point(x: 0, y: -50), size: Size(width: 500, height: 700))
    space.add(editor, at: Point(x: 0, y: 240), size: Size(width: 450, height: 300))
    
    //Connetti la fotocamera all'editor grafico
    camera.fotoScattata.connect(to: editor.input)
    
    //Connetti la vista album all'editor fotografico
    camera.album.imageSelected.connect(to: editor.input)
    
    //Connetti l'editor grafico alla vista album
    editor.fotoSalvata.connect(to: camera.album.imageInput)
    
    //Connetti il pulsante di condivisione all'immagine selezionata dall'album
    camera.album.imageSelected.connect(to: editor.pulsanteCondivisione.imageInput)
}
}

