//#-hidden-code
//
//  main.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
import UIKit
import PlaygroundSupport

Process.setIsUser()
PlaygroundPage.current.needsIndefiniteExecution = true
let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy
let listener = LiveViewListener(for: proxy)
ComponentMessage.reset(origin: ComponentMessageOrigin.current).send(to: .live)

AuthorizationManager.requestAuthorization(for: .photoLibrary, waitUntilDone: true, completion: { authorized in
    PBLog("PhotoLibrary authorized: \(authorized)")
})
AuthorizationManager.requestAuthorization(for: .camera, waitUntilDone: true, completion: { authorized in
    PBLog("Camera authorized: \(authorized)")
})
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, proxy, listener)
//#-code-completion(description, hide, "(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat)", "(x: CGFloat, y: CGFloat)", "(x: Float, y: Float)", "(width: CGFloat, height: CGFloat)", "(width: Float, height: Float)", "(cgPoint: CGPoint)", "(cgSize: CGSize)")
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, public)
//#-code-completion(literal, show, array, boolean, color, dictionary, image, string, integer, nil)
//#-code-completion(keyword, show, for, func, if, let, var, while)
//#-code-completion(snippet, show, repeat, switch, protocol, enum, struct, class, return)
//#-code-completion(module, show, MyFiles)
//#-code-completion(identifier, show, !, !=, (, (), (_:), (_:fontSize:color:alignment:), (fontName:fontSize:color:), (fontName:fontSize:color:alignment:), (hue:saturation:brightness:alpha:), (named:), (position:size:), (red:green:blue:alpha:), (style:), (width:height:), (x:y:), (x:y:width:height:), ), *, +, +=, -, -=, ->, ., /, :, <, =, >, AcademyEngravedLET, ActivityButton, AmericanTypewriter, App, AppleSDGothicNeo, Arial, ArialRoundedMTBold, Avenir, AvenirNext, AvenirNextCondensed, Baskerville, Bodoni72, BradleyHand, Button, CameraView, ChalkDuster, ChalkboardSE, Cochin, Color, Copperplate, Courier, CourierNew, Didot, Double, FontName, Futura, Georgia, GillSans, HelmetCamera, Helvetica, HelveticaNeue, HiraginoMinchoProN, HiraginoSans, Image, ImageView, Impact, Input, Int, Label, MarkerFelt, Menlo, MyApp, MyCamera, MyPhotoEditor, Noteworthy, Optima, Output, Palatino, Papyrus, PartyLET, PhotoAlbum, PhotoAlbumView, PhotoCollection, PhotoEditor, PingFangSC, PingFangTC, Point, Point(x:y:), Pulse, Rect, SavoyeLET, Size, Size(width:height:), Slider, SnellRoundhand, Sound, SoundFX, Space, Style, Superclarendon, SwiftyCamera, SystemBoldItalic, SystemFontBlack, SystemFontBold, SystemFontHeavy, SystemFontLight, SystemFontMedium, SystemFontRegular, SystemFontSemibold, SystemFontThin, SystemFontUltraLight, SystemHeavyItalic, SystemItalic, TextSizeMode, TextStyle, Thonburi, TimesNewRoman, TrebuchetMS, UIColor, UIImage, Verdana, Zapfino, _:, _:at:, _:at:size:, _:fontSize:color:alignment:, _:volume:waitUntilDone:, add(_:at:), add(_:at:size:), album, alignment, alpha, append(_:), auto, backgroundColor, backgroundImage, bark, black, blue, borderColor, borderWidth, brightness, brown, cameraClick, cameraView, captionStyle, center, clank, clear, cloud, color, component, connect(to:), cornerRadius, coverView, cyan, darkGray, decorateWithEmojiBorder(space:emoji:count:), decorateWithFlowers(space:count:), decorateWithHearts(space:count:), decorateWithImages(space:count:), decorateWithLabel(space:), decorateWithRandomEmoji(space:count:), decorateWithSnowflakes(space:count:), decorateWithStars(space:count:), decorateWithSticker(space:), fixed, fixedHeight, fixedWidth, fontName, fontName:fontSize:color:, fontName:fontSize:color:alignment:, fontSize, frontRearButton, gray, green, height, hue, hue:saturation:brightness:alpha:, image, imageInput, imageMaskedBy(maskImage:), imageSelected, images, in:, includeBorder:, init(), input, intrinsicSize, isEmpty, isHidden, isOverlayImageCropped, isUsingFrontCamera, justified, kitty, left, lightGray, magenta, maskImage, maskImage:, maskPath, maximumTrackColor, minimumTrackColor, multiline, named:, natural, notifyInputs, notifyInputs(_:), orange, overlaid(with:scaledBy:offsetBy:), overlayImage, overlayImageOffset, overlayImageScale, photoCollection, photoEditor:, photoSaved, photoTaken, photoTakingFlashColor, pi, plain, playSound(_:volume:waitUntilDone:), pointsAroundBorderOf(space:margin:count:), pointsAroundCornersOf(space:count:), pointsInCircleWith(radius:count:around:), position, position:size:, purple, radius:count:around:, random(in:), randomPointsWithin(space:count:), red, red:green:blue:alpha:, remove(_:), removeAll(), reset(), right, rocket, rotation, saturation, scale, scaleToFit(within:), scaledToFit(within:), shadowColor, shadowOffset, shark, showGrid(), shutterButton, size, sliderColor, sliderImage, snapshotTaken, snapshotTakingFlashColor, space, space:, space:count:, space:emoji:count:, space:margin:count:, sqrt(), start(), stop(), style:, subcomponents, takePhoto(), takeSnapshot(), takeSnapshot(includeBorder:), pressCountChanged, pressed, text, textSizeMode, textStyle, textStyle(_:fontSize:color:alignment:), title, to:, trigger, useCrystallizeFilter(photoEditor:), useMonochromeFilter(photoEditor:), value, valueChanged, white, width, width:height:, with:scaledBy:offsetBy:, within:, x, x:y:, x:y:width:height:, y, yellow, zero, zoom, {, })
//#-editable-code
//#-localizable-zone(StartingPointTemplate01)
// Create the space
//#-end-localizable-zone
let space = Space()

//#-localizable-zone(StartingPointTemplate02)
// Create the components.
//#-end-localizable-zone
let camera = SwiftyCamera(style: .plain)


//#-localizable-zone(StartingPointTemplate03)
// Add the components to the space.
//#-end-localizable-zone
space.add(camera, at: Point(x: 0, y: -150))

//#-localizable-zone(StartingPointTemplate04)
// Start the camera.
//#-end-localizable-zone
camera.start()

//#-end-editable-code
//#-hidden-code
//#-end-hidden-code
