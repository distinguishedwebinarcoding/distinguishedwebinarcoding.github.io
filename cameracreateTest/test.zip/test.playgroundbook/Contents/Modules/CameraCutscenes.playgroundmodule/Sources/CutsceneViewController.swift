//
//  CutsceneViewController.swift
//
//  Copyright © 2016-2021 Apple Inc. All rights reserved.
//

import UIKit

@objc(CutsceneViewController)
open class CutsceneViewController: UIViewController {
    /// Called when all animations in a given scene have completed.
    ///
    /// Signals other components that the animations have completed.
    public func animationsDidComplete() {

        NotificationCenter.default.post(name: .CutsceneAnimationDidComplete, object: self)
    }

}
