//
//  LiveComponent.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport
import UIKit

public protocol LiveComponent: class {
    var component: Component? { get }
    init(component: Component)
}

extension LiveComponent {
    
    // Default implementation
}

extension LiveComponent where Self: UIView {
    
    // Sets the default accessibility information for a live component.
    func setAccessibilityInfo() {
        guard let component = component else { return }
        let componentType = String(describing: type(of: component))
        accessibilityIdentifier = "\(componentType).\(component.name)"
        accessibilityLabel = String(describing: type(of: component))
    }
}
