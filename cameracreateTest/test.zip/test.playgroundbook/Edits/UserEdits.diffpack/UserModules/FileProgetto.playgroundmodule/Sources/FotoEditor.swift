
import Foundation 
import SPCComponents

public class FotoEditor: Space {
    // Definisco una spazio per contenere la foto
    public let spazioFoto = Space()
    let immagine = ImageView()
    let pulsanteSalva = Button()
    let pulsanteCancella = Button()
    let pulsanteCondivisione = ActivityButton()
    let pulsanteSelettoreDecorazione = Button()
    let pulsanteDecora = Button()
    let pulsanteDecoraConTesto = Button()
    var selettoreDecorazione = 0
    
    public var input = Input<Image>()
    public var fotoSalvata = Output<Image>()
    
    public override init() {
        super.init()
        backgroundColor = #colorLiteral(red: 1.0026154518127441, green: 0.8410214781761169, blue: 0.4673088788986206, alpha: 1.0)
        borderColor = #colorLiteral(red: 0.18823501467704773, green: 0.5901960730552673, blue: 0.6627453565597534, alpha: 1.0)
        borderWidth = 3
        cornerRadius = 30
        immagine.image = #imageLiteral(resourceName: "cf_floatyCloudsWP.png")
        immagine.borderColor = #colorLiteral(red: 1.0000003576278687, green: 0.4156862795352936, blue: 4.8130750940345024e-08, alpha: 1.0)
        immagine.borderWidth = 1
        
        // Aggiungi componenti
        add(spazioFoto, at: Point(x: 0, y: 0), size: Size(width: 250, height: 250))
        spazioFoto.add(immagine, at: Point(x: 0, y: 0), size: Size(width: 250, height: 250))
        add(pulsanteCondivisione, at: Point(x: 170, y: 90))
        add(pulsanteSalva, at: Point(x: 170, y: 00))
        add(pulsanteCancella, at: Point(x: 170, y: -90))
        add(pulsanteSelettoreDecorazione, at: Point(x: -170, y: 90))
        add(pulsanteDecora, at: Point(x: -170, y: 00))
        add(pulsanteDecoraConTesto, at: Point(x: -170, y: -90))
                
        // Imposta proprietà componenti 
        pulsanteCancella.image = #imageLiteral(resourceName: "cf_cancel-icon.png")
        pulsanteSalva.image = #imageLiteral(resourceName: "cf_save-icon.png")
        pulsanteCondivisione.image = #imageLiteral(resourceName: "cf_share-icon.png")
        impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "\u{1F4CC}", zoom: 2.0)
        impostaPulsante(button: pulsanteDecora, emoji: "🪄", zoom: 2.3)
        impostaPulsante(button: pulsanteDecoraConTesto, emoji: "✏️", zoom: 2.0)
        
        // Inizializza l'invito dell'ìmmagine: la foto scattata viene visualizza nell'editor
        input = Input<Image>({ image in
            self.immagine.image = image
            })
       
        func impostaPulsante(button: Button, emoji: String, zoom: Double) {
            button.title = emoji
            button.backgroundColor = .clear
            button.scale = zoom
        }
        
        // Connetti i componenti 
        pulsanteSalva.pressed.connect(to: pulsanteSalvaSelezionato)
        spazioFoto.snapshotTaken.connect(to: snapshotAcquisito)        
        pulsanteCancella.pressed.connect(to: pulsanteCancellaSelezionato)
        pulsanteDecora.pressed.connect(to: pulsanteDecoraSelezionato)
        pulsanteSelettoreDecorazione.pressed.connect(to: pulsanteSelettoreDecorazioneSelezionato)
        pulsanteDecoraConTesto.pressed.connect(to: pulsanteDecoraConTestoSelezionato)
        
        //Gestici le reazione dei pulsanti alla pressione
        
        // Reazione al tap sul pulsante Salva
        func pulsanteSalvaSelezionato(pulse: Pulse) {
            spazioFoto.takeSnapshot()
        }
        
       func snapshotAcquisito(image: Image) {
            fotoSalvata.notifyInputs(image)
        }
        
        func pulsanteApplicaImmaginiSelezionato(pulse: Pulse) {
            decorateWithImages(space: spazioFoto, count: 2)
        }
        
        func pulsanteSelettoreDecorazioneSelezionato(tap: Pulse) {
            if selettoreDecorazione < 7 {
                selettoreDecorazione += 1
            } else {
                selettoreDecorazione = 0
                }
            impostaImmaginePulsanteDecorazione(selettoreDecorazione)
        }
        
        func impostaImmaginePulsanteDecorazione(_ selettoreDecorazione: Int) {
            switch selettoreDecorazione {
            case 0:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "\u{1F4CC}", zoom: 2.0) 
            case 1:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "📚", zoom: 2.0)
            case 2:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "🌺", zoom: 2.0)
            case 3:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "💗", zoom: 2.0)
            case 4:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "❄️", zoom: 2.0)
            case 5:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "⭐️", zoom: 2.0)
            case 6:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "🖼️", zoom: 2.0)
            default:
                impostaPulsante(button: pulsanteSelettoreDecorazione, emoji: "🤖", zoom: 2.0) 
                                    }
        }
        
        func pulsanteDecoraSelezionato(pulse: Pulse) {
            switch selettoreDecorazione {
            case 0:
                decorateWithSticker(space: spazioFoto) 
            case 1:
               decorateWithLabel(space: spazioFoto)
           // decorateWithFlowers(space: spazioFoto, count: 5)
            case 2:
                decorateWithFlowers(space: spazioFoto, count: 5)
            case 3:
                decorateWithHearts(space: spazioFoto, count: 5)
            case 4:
                decorateWithSnowflakes(space: spazioFoto, count: 5)
            case 5:
                decorateWithStars(space: spazioFoto, count: 5)
            case 6:
                decorateWithImages(space: spazioFoto, count: 5)
            default:
                decorateWithEmojiBorder(space: spazioFoto, emoji: "🤖", count: 5) 
            }
        }
        
        func pulsanteDecoraConTestoSelezionato(tap: Pulse) {
            // Add the words.
            generaMeme(spazio: spazioFoto)
           
        }
        
     func pulsanteCancellaSelezionato(pulse: Pulse) {
            for componente in spazioFoto.subcomponents {
                if componente != immagine {
                    spazioFoto.remove(componente)
                }
            }
        }
    
    }
}


