import SPCComponents
import Foundation

public class MyApp: App {
    
    public let space = Space()
    let camera = FotoCamera()
    let editor = FotoEditor()
    
  public init() {
    // Aggiungo i componenti allo spazio
    space.add(camera, at: Point(x: 0, y: -50), size: Size(width: 500, height: 700))
    space.add(editor, at: Point(x: 0, y: 240), size: Size(width: 450, height: 300))
    
    //Connetto la fotocamera all'editor grafico
    camera.fotoScattata.connect(to: editor.input)
    
    //Connetto la vista album all'editore fotografico    
    camera.album.imageSelected.connect(to: editor.input)
    
    //Connetto l'editor grafico alla vista album
    editor.fotoSalvata.connect(to: camera.album.imageInput)
    
    //Connetto il pulsante di condivisione all'immagine selezionata dall'album
    camera.album.imageSelected.connect(to: editor.pulsanteCondivisione.imageInput)
}
}
