//
//  ComponentSpaceViewController.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit
import AVFoundation
import PlaygroundSupport
import SPCCore
import SPCComponents

@objc(ComponentSpaceViewController)
public class ComponentSpaceViewController: UIViewController, PlaygroundLiveViewSafeAreaContainer {
    
    private let tableauSize = CGSize(width: 1000, height: 1000)
    private let sceneSize = CGSize(width: 800, height: 800)
    private let buttonSize = CGSize(width: 44, height: 44)
    private let compactLayoutSize = CGSize(width: 507.0, height: 364.0)
    private let buttonInset: CGFloat = 20.0
    
    private let scrollView = UIScrollView()
    private let containerView = UIView()
    private let tableauView = UIView()
    private let gridView = GridView()
    private let liveContainerView = LiveContainerView() // Container view for Component live views.
    private var rootSpace: Space?
    private var statusLabel = UILabel()
    private var connectionsLayer = CALayer()
            
    private var containerViewTopConstraint: NSLayoutConstraint!
    private var containerViewBottomConstraint: NSLayoutConstraint!
    private var containerViewLeadingConstraint: NSLayoutConstraint!
    private var containerViewTrailingConstraint: NSLayoutConstraint!

    private static var cameraNotAvailableAlertShown = false
    private var hadRequestedCameraAuthorization = false

    // MARK: View Controller Lifecycle

    override public func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        scrollView.minimumZoomScale = 0.5
        scrollView.maximumZoomScale = 4.0
        scrollView.delegate = self
        scrollView.canCancelContentTouches = false
        view.addSubview(scrollView)
        
        containerView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(containerView)

        gridView.translatesAutoresizingMaskIntoConstraints = false
        gridView.alpha = 0.3
        tableauView.addSubview(gridView)
        
        tableauView.translatesAutoresizingMaskIntoConstraints = false
        tableauView.layer.addSublayer(connectionsLayer)
        containerView.addSubview(tableauView)
        
        liveContainerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(liveContainerView)
        
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.textColor = .yellow
        statusLabel.font = UIFont(name: "Menlo", size: 14.0)!
        statusLabel.backgroundColor = .darkGray
        statusLabel.alpha = 0.75
        statusLabel.isHidden = true
        view.addSubview(statusLabel)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leftAnchor.constraint(equalTo: view.leftAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.rightAnchor.constraint(equalTo: view.rightAnchor)
        ])
        
        containerViewTopConstraint = containerView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 0.0)
        containerViewBottomConstraint = containerView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 0.0)
        containerViewLeadingConstraint = containerView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 0.0)
        containerViewTrailingConstraint = containerView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: 0.0)
        
        NSLayoutConstraint.activate([
            containerViewTopConstraint,
            containerViewBottomConstraint,
            containerViewLeadingConstraint,
            containerViewTrailingConstraint,
            containerView.widthAnchor.constraint(equalToConstant: tableauSize.width),
            containerView.heightAnchor.constraint(equalToConstant: tableauSize.height)
        ])
        
        NSLayoutConstraint.activate([
            tableauView.topAnchor.constraint(equalTo: containerView.topAnchor),
            tableauView.leftAnchor.constraint(equalTo: containerView.leftAnchor),
            tableauView.widthAnchor.constraint(equalTo: containerView.widthAnchor),
            tableauView.heightAnchor.constraint(equalTo: containerView.heightAnchor)
        ])
        
        NSLayoutConstraint.activate([
            liveContainerView.topAnchor.constraint(equalTo: containerView.topAnchor),
            liveContainerView.leftAnchor.constraint(equalTo: containerView.leftAnchor),
            liveContainerView.widthAnchor.constraint(equalTo: containerView.widthAnchor),
            liveContainerView.heightAnchor.constraint(equalTo: containerView.heightAnchor)
        ])
        
        NSLayoutConstraint.activate([
            gridView.topAnchor.constraint(equalTo: tableauView.topAnchor),
            gridView.leftAnchor.constraint(equalTo: tableauView.leftAnchor),
            gridView.widthAnchor.constraint(equalTo: tableauView.widthAnchor),
            gridView.heightAnchor.constraint(equalTo: tableauView.heightAnchor)
        ])
        
        NSLayoutConstraint.activate([
            statusLabel.topAnchor.constraint(equalTo: view.topAnchor),
            statusLabel.leftAnchor.constraint(equalTo: view.leftAnchor),
            statusLabel.widthAnchor.constraint(equalTo: view.widthAnchor),
            statusLabel.heightAnchor.constraint(equalToConstant: 30.0)
        ])
        
        ComponentManager.shared.isRunningInLiveView = true
        
        reset()
        
        // Register for AVCaptureSession interruption notifications.
        NotificationCenter.default.addObserver(self, selector: #selector(onAVCaptureSessionInterrupted), name: .AVCaptureSessionWasInterrupted, object: nil)
        // Save the initial camera authorization state.
        hadRequestedCameraAuthorization = AuthorizationManager.hasRequestedCameraAuthorization
    }

    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        view.setNeedsLayout()
        
        //TestSpaces.swiftyCameraWithImageView(in: self.rootSpace())
    }
    
    // MARK: Layout
    
    override public func viewDidLayoutSubviews() {
        
        // Ensure that the full height of containerView is always visible. Zoom out if necessary.
        if view.bounds.size.height < tableauSize.height {
            let zoomScale = view.bounds.size.height / tableauSize.height
            scrollView.zoomScale = zoomScale
        }
        
        // Adjust scroll offset so that containerView is horizontally centered.
        DispatchQueue.main.async {
            self.updateConstraintsForSize(self.view.bounds.size)
            let initialXOffset = (self.containerView.bounds.size.width * self.scrollView.zoomScale / 2.0) - (self.view.frame.width / 2.0)
            if initialXOffset > 0 {
                self.scrollView.contentOffset = CGPoint(x: initialXOffset, y: 0.0)
            }
        }
    }
    
    override public func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: {  _ in
        }, completion: { _ in
            self.view.setNeedsLayout()
            if Process.isLiveViewConnectionOpen {
                NotificationCenter.default.post(name: .componentViewSizeChanged, object: nil)
            }
        })
    }

    private func updateConstraintsForSize(_ size: CGSize) {
        // Keep containerView centered within scrollView.
        let yOffset: CGFloat = max(0.0, (size.height - containerView.frame.height) / 2.0)
        containerViewTopConstraint.constant = yOffset
        containerViewBottomConstraint.constant = yOffset
        let xOffset: CGFloat = max(0.0, (size.width - containerView.frame.width) / 2.0)
        containerViewLeadingConstraint.constant = xOffset
        containerViewTrailingConstraint.constant = xOffset
    }
    
    // MARK: Notifications
    
    // Handle AVCaptureSession interruption notifications.
    @objc
    func onAVCaptureSessionInterrupted(notification: NSNotification) {
        guard let userInfoValue = notification.userInfo?[AVCaptureSessionInterruptionReasonKey] as AnyObject?,
            let reasonIntegerValue = userInfoValue.integerValue,
            let reason = AVCaptureSession.InterruptionReason(rawValue: reasonIntegerValue) else { return }
        
        guard reason == .videoDeviceNotAvailableWithMultipleForegroundApps, !hadRequestedCameraAuthorization, !(type(of: self)).cameraNotAvailableAlertShown else { return }
        
        // The camera is not available in split view or slide over multitasking modes.
        // If camera authorization hadn’t been requested before the live view was loaded (i.e. first time for this playgroundbook),
        // and if the alert hasn’t been shown before,
        // => show alert once per loaded playground book (similar to camera authorization).
        PBLog("Camera not available in multiple foreground apps: show alert.")
        let alert = UIAlertController(title: NSLocalizedString("Camera Not Available", comment: "Camera not available alert title"),
                                      message: NSLocalizedString("The camera is not available when you use Swift Playgrounds in Split View or Slide Over mode.", comment: "Camera not available alert message"),
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "OK button"), style: .cancel, handler: nil))
        present(alert, animated: true)
        (type(of: self)).cameraNotAvailableAlertShown = true
    }

    // MARK: Custom

    // Returns the current root Space. Creates and adds one if none exists.
    func rootSpace(for suppliedSpaceComponent: Space? = nil) -> Space {
        if let spaceComponent = rootSpace {
            return spaceComponent
        }
        
        // No existing rootSpace yet, so use supplied component or create one.
        var spaceComponent: Space
        if let component = suppliedSpaceComponent {
            spaceComponent = component
        } else {
            spaceComponent = Space(name: "space")
        }
        
        rootSpace = spaceComponent
        
        // Add the rootSpace's live view to the view.
        spaceComponent.position = Point.zero
        spaceComponent.size = Size(tableauSize)
        self.rootSpace = spaceComponent
        if let liveSpace = spaceComponent.liveComponent as? LiveSpace {
            //PBLog("rootSpace \(type) \(identity.name) \(identity.id)")
            liveContainerView.addSubview(liveSpace)
            liveSpace.frame = tableauView.bounds
            liveSpace.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            
            liveSpace.isRootSpace = true
        }
        return spaceComponent
    }
    
    // Clears the current root Space, removing all components.
    func reset() {
        // Dismiss any presented view controllers such as an activity sheet.
        dismiss(animated: false, completion: nil)

        ComponentManager.shared.reset()
        connectionsLayer.sublayers?.forEach({ $0.removeFromSuperlayer()} )
        if let liveSpace = rootSpace?.liveComponent as? LiveSpace {
            liveSpace.removeFromSuperview()
            rootSpace = nil
        }
    }
        
    // MARK: Messaging
    
    func handleCameraFunMessage(message: CameraFunMessage) {
        switch message {
        case .showGrid(origin: _):
            gridView.isHidden = false
        }
    }

    func handleComponentMessage(message: ComponentMessage) {
        switch message {
        case let .initComponent(origin: _, type: type, identity: identity):
            //PBLog("initComponent \(type) \(identity.name) \(identity.id)")
            
            // Create a component of type with the specified identity.
            guard let newComponent = PlaceableComponent.createComponent(type: type, identity: identity) else { return }
            
            // If it’s the first Space to be created, treat it as the root space.
            if rootSpace == nil, let newSpaceComponent = newComponent as? Space {
                let _ = rootSpace(for: newSpaceComponent)
            }
        case let .deinitComponent(origin: _, identity: identity):
            //PBLog("deinitComponent \(identity.description)")
            // Deregister the component.
            ComponentManager.shared.deregisterComponentWith(identity: identity)
        case let .event(origin: origin, identity: identity, event: event):
            
            // Search for component with a local identity.
            if let component = ComponentManager.shared.component(for: identity) {
                component.receive(event, from: origin)
                return
            }
        case .reset:
            reset()
        }
    }
}

// MARK: UIScrollViewDelegate
extension ComponentSpaceViewController: UIScrollViewDelegate {
    
    public func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return containerView
    }
    
    public func scrollViewDidZoom(_ scrollView: UIScrollView) {
        updateConstraintsForSize(view.bounds.size)
    }
}

// MARK: PlaygroundLiveViewMessageHandler
extension ComponentSpaceViewController: PlaygroundLiveViewMessageHandler {
    
    public func receive(_ message: PlaygroundValue) {
        if let componentMessage = ComponentMessage(playgroundValue: message) {
            handleComponentMessage(message: componentMessage)
        } else if let cameraFunMessage = CameraFunMessage(playgroundValue: message) {
            handleCameraFunMessage(message: cameraFunMessage)
        }
    }
    
    public func liveViewMessageConnectionOpened() {
        PBLog("liveViewMessageConnectionOpened")
        Process.isLiveViewConnectionOpen = true
        Process.setIsLive()
        scrollView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        gridView.isHidden = true
    }
    
    public func liveViewMessageConnectionClosed() {
        PBLog("liveViewMessageConnectionClosed")
        Process.isLiveViewConnectionOpen = false
        scrollView.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        gridView.isHidden = false
        reset()
    }
}
