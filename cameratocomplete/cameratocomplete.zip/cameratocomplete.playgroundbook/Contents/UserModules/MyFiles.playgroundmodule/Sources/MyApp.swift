import SPCComponents
import Foundation
//#-localizable-zone(StartingPointMyApp01)
// App component using the helmet camera and photo editor.
//#-end-localizable-zone
public class MyApp: App {
//#-localizable-zone(StartingPointMyApp02)
    // Create the space.
//#-end-localizable-zone
    public let space = Space()

//#-localizable-zone(StartingPointMyApp03)
    // Create the components.
//#-end-localizable-zone
    let camera = HelmetCamera()
    let albumView = PhotoAlbumView()
    let photoEditor = PhotoEditor()
    
//#-localizable-zone(StartingPointMyApp04)
    // Initialize the app.
//#-end-localizable-zone
    public init() {
//#-localizable-zone(StartingPointMyApp05)
        // Add the components to the space.
//#-end-localizable-zone
        space.add(albumView, at: Point(x: 0, y: 320), size: Size(width: 500, height: 120))
        space.add(photoEditor, at: Point(x: 0, y: 80), size: Size(width: 500, height: 280))
        space.add(camera, at: Point(x: 0, y: -240), size: Size(width: 300, height: 300))

//#-localizable-zone(StartingPointMyApp06)
        // Start the camera.
//#-end-localizable-zone
        camera.start()
        
//#-localizable-zone(StartingPointMyApp07)
        // Open your photo album.
//#-end-localizable-zone
        let myAlbum = PhotoAlbum(named: "/*#-localizable-zone(StartingPointMyFiles)*/MY ALBUM NAME/*#-end-localizable-zone*/")
        albumView.album = myAlbum
        
//#-localizable-zone(StartingPointMyApp08)
        // Style the album view.
//#-end-localizable-zone
        albumView.backgroundColor = #colorLiteral(red: 0.05882352963, green: 0.180392161, blue: 0.2470588237, alpha: 1)
        albumView.borderWidth = 4
        albumView.borderColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        albumView.cornerRadius = 10.0
        albumView.captionStyle = TextStyle(.SystemFontRegular, fontSize: 14, color: #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1), alignment: .center)
        
//#-localizable-zone(StartingPointMyApp09)
        // Connect the camera to the photo editor.
//#-end-localizable-zone
        camera.photoTaken.connect(to: photoEditor.input)
        
//#-localizable-zone(StartingPointMyApp10)
        // Connect the album view to the photo editor.
//#-end-localizable-zone
        albumView.imageSelected.connect(to: photoEditor.input)
        
//#-localizable-zone(StartingPointMyApp11)
        // Connect the photo editor to the album view.
//#-end-localizable-zone
        photoEditor.photoSaved.connect(to: albumView.imageInput)
    }
}
